const prompt = require('prompt-sync')();

let nome = prompt("Nome do Jogador: ");
let pontuacao =  Number(prompt("Pontuação: "));
let pontuacaoMinima = 1800;

console.log("Analisando Perfil... ");

if(pontuacao >= pontuacaoMinima) {
 console.log("APROVADO!!!", nome," tem nivel para a equipe principal.");
} else {
 let pontosFaltando = pontuacaoMinima - pontuacao;
 console.log("REPROVADO! ", nome," precisa de mais ", pontosFaltando, " pontos para entrar na equipe principal.");
}
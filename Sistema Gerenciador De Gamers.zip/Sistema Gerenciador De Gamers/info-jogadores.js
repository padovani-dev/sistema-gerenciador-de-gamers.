let nomeJogador = "Fallen";
let pontuacao = 12000;
const equipe = "Os Ninjas";
let statusAtivo = true; 

console.log("----- Informações do Jogador ----- ");
console.log("Nome do Jogador: ", nomeJogador);
console.log("Equipe: ", equipe);
console.log("Pontuação: ", pontuacao);

console.log ("----- Pontuação atualizada após campeonato -----");

pontuacao = pontuacao + 600;

console.log("Pontuação do Ranking atualizada: ", pontuacao);

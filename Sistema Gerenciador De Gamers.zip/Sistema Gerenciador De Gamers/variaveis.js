// Strings 
let nomejogador = "Fallen";

// Boleano -> True (Verdadeiro) ou False (Falso)
let statusAtivo = true;

// Numero/Inteiro
let pontuacao = 1250; 

// Constantes
const equipe = "Ninjas In Pyjamas"; 

console.log("----- Perfil Do Capitão -----");
console.log(" Jogador:", nomejogador);
console.log("Time:", equipe);
console.log("Pontos no ranking:", pontuacao); 

pontuacao = pontuacao + 200;

console.log("Pontuação após vitória:", pontuacao);

nomeJogador = "Cap Joga";

console.log("Novo Jogador: ", nomeJogador);
